#!/bin/sh

# Uninstall the Required C++ Runtimes & the Program "fcheck"
rm -rf        /usr/local/lib/fcheck/

rm -rf        /usr/local/bin/fcheck

# Uninstall the Documentation Files
rm -rf        /usr/local/share/man/man1/fcheck.1
rm -rf        /usr/local/share/fcheck/


