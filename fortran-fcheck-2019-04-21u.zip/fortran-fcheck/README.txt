  Apr 21, 2019


  This Directory contains the command "fcheck", a parser
  (front-end) that validates syntactically a Fortran program.

  You can install it on a Mac, Linux, or Windows i386/x86_64
  system by following one of these instructions respectively:

  1. Install/Uninstall "fcheck" on OS X or macOS
  2. Install/Uninstall "fcheck" on Linux
  3. Install/Uninstall "fcheck" on Windows via Cygwin (TM)

  The installer runs from the command line in a terminal and
  the user must have administrator privileges. Choose one of:


  1. To install the command "fcheck" on an Intel based Mac, go
     to the directory "OS-X-10.9" and type

     ./install.sh

     The installed program runs on OS X (10.9) - macOS (10.13).

     A manual is available in these platforms, to read it type:

     man fcheck

     If the installation has not run properly or the command
     "fcheck" isn't functional in your system, type:

     ./uninstall.sh


  2. To install the command "fcheck" on Linux, go to the
     directory RedHat-9 and type:

     ./install.sh

     You need the "libstdc++.so.5" i386 version installed.
     Search for the RPM package named "libstdc++-3.2.2", if
     the required library isn't installed in your system.

     A manual is available in this platform, to read it type:

     man fcheck

     If the installation has not run properly or the command
     "fcheck" isn't functional in your system, type:

     ./uninstall.sh
       

     Notes
     -----
     2.1 The required GNU C++ Library is covered by the
     Lesser GPL (version 3) License which can be found at:
     https://www.gnu.org/licenses/license-list.html#LGPL
 

  3. To install the command "fcheck" on Windows, follow the
     first step below and optionally either the second step if
     you have a recent version of Windows or the third step if
     you have an older version of windows. 
  
     3.1 To install the command "fcheck" on Cygwin (TM), open a
         Cygwin32 or Cygwin64 Terminal, then go to the directory
         Cygwin32 or Cygwin64 respectively, and type:

         ./install.sh

         A manual is available in this system, to read it type:

         man fcheck

         If the installation has not run properly or the command
         "fcheck" isn't functional in your system, type:

         ./uninstall.sh

         If on the other hand the installation has run successfully
         and you plan to run the steps 3.2 or 3.3 below, then type:

         ./collect.sh

         The above script will collect the required Libraries for a
         subsequent, native installation of the command "fcheck".


         Notes
         -----
         3.1.1 The required Cygwin (TM) API Library is covered by
         the Lesser GPL (version 3) License which can be found at:
         https://www.gnu.org/licenses/license-list.html#LGPL

         3.1.2 The required GNU C++ Library is covered by the
         Lesser GPL (version 3) License which can be found at:
         https://www.gnu.org/licenses/license-list.html#LGPL


     3.2 To install the command fcheck as a stand-alone application
         that runs in Windows consoles, Run a PowerShell Console as
         Administrator, then go to the directory Cygwin32/Cygwin64
         where you have run the step "3.1" above and type:

         .\install.bat

         Before running the above script close any open Windows
         to ensure that no other application is editing the system
         environment variable 'Path' at the same time.

         If everything has worked as supposed to, then the command
         "fcheck" may be available in new terminal sessions or you
         will have to logout first. In any case, close the terminal
         without running this script again.

         If on the other hand the installer hasn't run as expected,
         then examine how far the installation has proceeded. If the
         file "C:\Program Files\Fortran-Parser\saved\old-path.txt"
         has been created, restore the 'Path' as needed and run:

         .\uninstall.bat


     3.3 To install the 32bit version of the program in older Windows
         versions that don't have a PowerShell Console, Run a Command
         Prompt as Administrator, then go to the directory Cygwin32
         where you have run the step "3.1" above and type:

         .\install.bat

         Before running the above script close any open Windows
         to ensure that no other application is editing the system
         environment variable 'Path' at the same time.

         The Command Prompt may close instantly when the script exits,
         without giving you the time to read any written messages. So,
         have a look at: "C:\Program Files\Fortran-Parser"

         If the installer hasn't run as expected, examine if the file
         "C:\Program Files\Fortran-Parser\saved\old-path.txt" has been 
         created. If yes, restore the 'Path' as needed and then run:

         .\uninstall.bat

         This binary may run in systems older than Windows 8.1 but not
         in Windows XP.


     In Windows, the manual of the command "fcheck" is installed at:

     "C:\Program Files\Fortran-Parser\share\user-manual.pdf"

 -----------------------------------------------------------------------

