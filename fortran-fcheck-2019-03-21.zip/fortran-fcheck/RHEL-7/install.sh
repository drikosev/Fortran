#!/bin/sh

# Prepare the Installation Directores

sudo install -d /usr/local/lib/fcheck/
sudo install -d /usr/local/lib64/fcheck/
sudo install -d /usr/local/bin/
sudo install -d /usr/local/share/man/man1/
sudo install -d /usr/local/share/fcheck/

# Install the Required C++ Runtimes & the Program "fcheck"
sudo install  -p -m 755 lib/libstdc++.so.6.0.19    /usr/local/lib/fcheck/libstdc++.so.6 
sudo install  -p -m 755 lib64/libstdc++.so.6.0.19  /usr/local/lib64/fcheck/libstdc++.so.6 

sudo install -p -m 755  fcheck                     /usr/local/bin/fcheck

# Install the Documentation Files
sudo install  -p -m 644 ../fcheck.1             /usr/local/share/man/man1/fcheck.1
sudo install  -p -m 644 ../LICENSE              /usr/local/share/fcheck/fcheck-license.txt
sudo install  -p -m 644 ../fortran-parser.html  /usr/local/share/fcheck/fortran-parser.html
sudo install  -p -m 644 ../fortran-scanner.html /usr/local/share/fcheck/fortran-scanner.html


