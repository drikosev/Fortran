#!/bin/sh

# Prepare the Installation Directores

sudo install -d /usr/local/lib/fcheck/
sudo install -d /usr/local/bin/
sudo install -d /usr/local/share/man/man1/
sudo install -d /usr/local/share/fcheck/

# Install the Required C++ Runtime & the Program "fcheck"
mac_min=`sw_vers -productVersion | awk -F "." '{print $1 "." $2}'`
if [ -d lib/${mac_min} ] ; then
   sudo install  -p -m 755 lib/${mac_min}/libc++.1.dylib  /usr/local/lib/fcheck/libc++.1.dylib 
else
   sudo install  -p -m 755 lib/libc++.1.dylib             /usr/local/lib/fcheck/libc++.1.dylib 
fi
sudo install  -p -m 755 fcheck                 /usr/local/bin/fcheck

# Install the Documentation Files
sudo install  -p -m 644 ../fcheck.1             /usr/local/share/man/man1/fcheck.1
sudo install  -p -m 644 ../fcheck.1.pdf         /usr/local/share/fcheck/user-manual.pdf
sudo install  -p -m 644 ../LICENSE.txt          /usr/local/share/fcheck/fcheck-license.txt
sudo install  -p -m 644 ../fortran-parser.htm   /usr/local/share/fcheck/fortran-parser.htm
sudo install  -p -m 644 ../fortran-scanner.htm  /usr/local/share/fcheck/fortran-scanner.htm


