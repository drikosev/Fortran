#!/bin/sh

# Uninstall the Required C++ Runtime & the Program "fcheck"
sudo rm -rf        /usr/local/lib/fcheck/

sudo rm -rf        /usr/local/bin/fcheck

# Uninstall the Documentation Files
sudo rm -rf        /usr/local/share/man/man1/fcheck.1
sudo rm -rf        /usr/local/share/fcheck/


